#pragma once

#define DYNAMIC_KEYMAP_LAYER_COUNT 3

#define EE_HANDS

#define ENCODERS_PAD_A { F4 }
#define ENCODERS_PAD_B { F5 }